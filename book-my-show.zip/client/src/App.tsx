import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { Link, Route, Switch, useLocation } from "wouter";
import { CalendarCheck, Clapperboard, Heart, Home as HomeIcon, LogIn, LogOut, Menu, Moon, ShieldCheck, Sun, Ticket, UserCircle, X } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { useTheme } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Movies from "./pages/Movies";
import MovieDetails from "./pages/MovieDetails";
import SeatBooking from "./pages/SeatBooking";
import Payment from "./pages/Payment";
import Bookings from "./pages/Bookings";
import Confirmation from "./pages/Confirmation";
import Admin from "./pages/Admin";
import Theaters from "./pages/Theaters";
import NotFound from "./pages/NotFound";

function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navItems = [
    { href: "/", label: "Home", icon: HomeIcon },
    { href: "/movies", label: "Movies", icon: Clapperboard },
    { href: "/my-bookings", label: "My bookings", icon: Ticket },
  ];
  return (
    <header className="site-header">
      <div className="shell nav-inner">
        <Link href="/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-mark"><Clapperboard size={18} /></span>
          <span>BOOK MY <b>SHOW</b></span>
        </Link>
        <button className="mobile-menu" onClick={() => setOpen((value) => !value)} aria-label="Toggle menu">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
        <nav className={open ? "nav-links open" : "nav-links"}>
          {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={location === href ? "nav-link active" : "nav-link"} onClick={() => setOpen(false)}><Icon size={15} />{label}</Link>)}
          <Link href="/theaters" className={location === "/theaters" ? "nav-link active" : "nav-link"} onClick={() => setOpen(false)}><Heart size={15} />Theaters</Link>
        </nav>
        <div className="nav-actions">
          <button className="icon-button theme-toggle" onClick={() => toggleTheme?.()} title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"} aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}>{theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}</button>
          {user?.role === "admin" && <Link href="/admin" className="admin-link"><ShieldCheck size={15} /> Admin</Link>}
          {isAuthenticated ? <>
            <Link href="/profile" className="profile-chip"><UserCircle size={16} />{user?.name?.split(" ")[0] ?? "Profile"}</Link>
            <button className="icon-button" onClick={() => logout()} title="Log out"><LogOut size={17} /></button>
          </> : <button className="login-button" onClick={() => startLogin()}><LogIn size={15} /> Sign in</button>}
        </div>
      </div>
    </header>
  );
}

function Router() {
  return <>
    <SiteHeader />
    <main>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/movies" component={Movies} />
        <Route path="/movie/:id" component={MovieDetails} />
        <Route path="/show/:id" component={SeatBooking} />
        <Route path="/payment/:id" component={Payment} />
        <Route path="/my-bookings" component={Bookings} />
        <Route path="/booking/:id" component={Confirmation} />
        <Route path="/theaters" component={Theaters} />
        <Route path="/admin" component={Admin} />
        <Route path="/profile" component={Bookings} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </main>
    <footer className="site-footer"><div className="shell footer-inner"><div><div className="brand footer-brand"><span className="brand-mark"><Clapperboard size={16} /></span><span>BOOK MY <b>SHOW</b></span></div><p>Make your movie night the main event.</p></div><div className="footer-meta"><span><CalendarCheck size={15} /> Instant confirmation</span><span><Ticket size={15} /> Secure mock checkout</span></div></div></footer>
  </>;
}

function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark" switchable><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
