import { Link } from "wouter";
import { Star, Ticket } from "lucide-react";

export type MovieCardData = {
  id: number;
  title: string;
  poster: string;
  genre: string;
  language: string;
  rating: number;
  releaseDate: string;
};

export default function MovieCard({ movie }: { movie: MovieCardData }) {
  return <article className="movie-card">
    <Link href={`/movie/${movie.id}`} className="movie-poster">
      <img src={movie.poster} alt={`${movie.title} poster`} loading="lazy" />
      <span className="rating-pill"><Star size={12} fill="currentColor" /> {movie.rating}.0</span>
    </Link>
    <div className="movie-info">
      <Link href={`/movie/${movie.id}`}><h3>{movie.title}</h3></Link>
      <div className="movie-meta"><span>{movie.genre}</span><span>•</span><span>{movie.language}</span></div>
      <div className="movie-meta" style={{ marginTop: 5 }}><span>Releases {movie.releaseDate}</span></div>
      <div className="movie-actions"><Link href={`/movie/${movie.id}`} className="ghost-button">Details</Link><Link href={`/movie/${movie.id}`} className="primary-button"><Ticket size={13} /> Book</Link></div>
    </div>
  </article>;
}
