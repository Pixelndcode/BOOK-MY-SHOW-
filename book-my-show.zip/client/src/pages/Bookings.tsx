import { CalendarDays, LogIn, Ticket } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";

export default function Bookings() {
  const { isAuthenticated, user } = useAuth();
  const { data: bookings = [], isLoading } = trpc.bookings.mine.useQuery(undefined, { enabled: isAuthenticated });
  if (!isAuthenticated) return <div className="shell page"><div className="empty-state"><LogIn size={28} color="#ff7e61" /><h2>Sign in to see your bookings</h2><p>All your tickets, in one place.</p><button className="primary-button" onClick={() => startLogin()}>Sign in</button></div></div>;
  return <div className="shell page"><div className="section-head"><div><div className="eyebrow">Your cinema diary</div><h1 style={{ margin: "7px 0", fontSize: 42 }}>{user?.name ? `${user.name.split(" ")[0]}'s bookings` : "My bookings"}</h1><p className="muted" style={{ margin: 0, fontSize: 13 }}>Keep every great movie night close.</p></div><Link href="/movies" className="primary-button"><Ticket size={15} /> Book another movie</Link></div>{isLoading ? <div className="loading">Loading your tickets…</div> : bookings.length ? <div className="booking-list">{bookings.map((booking) => <article className="booking-card" key={booking.id}><img className="booking-thumb" src={booking.moviePoster} alt="" /><div><h3>{booking.movieTitle}</h3><p><CalendarDays size={12} style={{ verticalAlign: "-2px" }} /> {booking.showDate} · {booking.showTime} · {booking.theaterName}</p><p>Seats: <strong style={{ color: "#dfe5eb" }}>{booking.seatNumbers.join(", ")}</strong> · ₹{booking.totalAmount}</p><span className="booking-id">{booking.bookingId}</span></div><div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 9 }}><span className={booking.status === "CONFIRMED" ? "status-pill" : "detail-tag"}>{booking.status}</span><Link href={`/booking/${booking.id}`} className="secondary-button">View ticket</Link></div></article>)}</div> : <div className="empty-state"><Ticket size={28} color="#ff7e61" /><h2>No bookings yet</h2><p>Your next movie night is one click away.</p><Link href="/movies" className="primary-button">Explore movies</Link></div>}</div>;
}
