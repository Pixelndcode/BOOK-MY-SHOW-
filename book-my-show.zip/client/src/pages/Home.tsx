import { Search, ShieldCheck, Sparkles, Ticket, TrendingUp } from "lucide-react";
import { FormEvent, useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import MovieCard from "@/components/MovieCard";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";

export default function Home() {
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const { data: movies = [], isLoading } = trpc.movies.list.useQuery({ limit: 4, sort: "rating" });
  const { isAuthenticated } = useAuth();
  const submitSearch = (event: FormEvent) => { event.preventDefault(); navigate(`/movies${search ? `?search=${encodeURIComponent(search)}` : ""}`); };
  return <>
    <section className="hero"><div className="shell hero-grid"><div className="hero-copy"><div className="eyebrow">Your seat is waiting</div><h1 className="display-title">Make tonight a <span>movie night.</span></h1><p>Find the stories worth leaving home for. Discover new releases, compare showtimes, and book your perfect seats in a few clicks.</p><div className="hero-actions"><Link href="/movies" className="primary-button"><Ticket size={16} /> Browse movies</Link>{!isAuthenticated && <button className="secondary-button" onClick={() => startLogin()}><ShieldCheck size={16} /> Sign in to book</button>}</div><div className="hero-note"><Sparkles size={15} color="#ff7e61" /><span><strong>Live showtimes</strong> across your favourite cinemas</span></div></div><div className="hero-art"><div className="hero-art-card"><small>Spotlight pick</small><strong>Stories in the dark</strong></div></div></div></section>
    <div className="shell"><div className="search-panel"><form className="search-form" onSubmit={submitSearch}><Search size={18} color="#74808c" style={{ alignSelf: "center", marginLeft: 4 }} /><input className="search-input" placeholder="Search by movie, genre or language" value={search} onChange={(event) => setSearch(event.target.value)} /><button className="primary-button" type="submit">Search</button></form></div>
      <section className="section"><div className="section-head"><div><div className="eyebrow">Curated for you</div><h2>Recommended movies</h2></div><Link href="/movies" className="text-link">View all movies →</Link></div>{isLoading ? <div className="loading">Loading the latest releases…</div> : <div className="movie-grid">{movies.map((movie) => <MovieCard key={movie.id} movie={movie} />)}</div>}</section>
      <div className="stats-strip"><div className="stat"><strong>5.0M+</strong><span>Tickets booked with joy</span></div><div className="stat"><strong>120+</strong><span>Cinemas to choose from</span></div><div className="stat"><strong>4.8 / 5</strong><span>Average movie-lover rating</span></div></div>
      <section className="section"><div className="section-head"><div><div className="eyebrow">Make plans</div><h2>Pick a mood</h2></div></div><div className="mood-grid" style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14 }}><Link href="/movies?genre=Action" className="mood-card" style={{ background: "linear-gradient(135deg,#502114,#1b1110)" }}><TrendingUp size={19} /><strong>Big screen energy</strong><span>Action & thrillers</span></Link><Link href="/movies?genre=Comedy" className="mood-card" style={{ background: "linear-gradient(135deg,#3b3b13,#15170d)" }}><Sparkles size={19} /><strong>Laugh out loud</strong><span>Comedy & comfort</span></Link><Link href="/movies?genre=Sci-Fi" className="mood-card" style={{ background: "linear-gradient(135deg,#122c42,#0e151d)" }}><Ticket size={19} /><strong>Go somewhere else</strong><span>Sci-fi & fantasy</span></Link></div></section>
    </div>
    <style>{`.mood-card{min-height:130px;padding:18px;border:1px solid #303944;border-radius:13px;color:#fff;display:flex;flex-direction:column;justify-content:space-between;transition:.2s}.mood-card:hover{transform:translateY(-3px);border-color:#5a6672}.mood-card strong{font-family:'Syne';font-size:16px}.mood-card span{color:#a0abb5;font-size:11px}`}</style>
  </>;
}
