import { Search, SlidersHorizontal } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import MovieCard from "@/components/MovieCard";

export default function Movies() {
  const [location, navigate] = useLocation();
  const initialSearch = new URLSearchParams(location.split("?")[1] ?? "").get("search") ?? "";
  const [search, setSearch] = useState(initialSearch);
  const [genre, setGenre] = useState("all");
  const [language, setLanguage] = useState("all");
  const [sort, setSort] = useState<"rating" | "release">("rating");
  const { data: movies = [], isLoading } = trpc.movies.list.useQuery({ search, genre, language, sort });
  useEffect(() => { const timer = window.setTimeout(() => navigate(`/movies${search ? `?search=${encodeURIComponent(search)}` : ""}`, { replace: true }), 150); return () => window.clearTimeout(timer); }, [search, navigate]);
  return <div className="shell page"><div className="section-head"><div><div className="eyebrow">The big screen awaits</div><h1 style={{ margin: "7px 0 0", fontSize: 42 }}>All movies</h1><p className="muted" style={{ margin: "10px 0 0", fontSize: 13 }}>Find your next favourite story, from first look to final credits.</p></div><div style={{ color: "#7e8995", fontSize: 12 }}>{movies.length} titles available</div></div>
    <div className="filter-bar"><div style={{ display: "flex", alignItems: "center", gap: 8, flex: 1, minWidth: 200 }}><Search size={16} color="#798591" /><input className="search-input" style={{ padding: "10px 0", background: "transparent" }} placeholder="Search title, genre or language" value={search} onChange={(event) => setSearch(event.target.value)} /></div><select className="select-input" value={genre} onChange={(event) => setGenre(event.target.value)}><option value="all">All genres</option><option>Action</option><option>Action / Thriller</option><option>Comedy / Drama</option><option>Horror / Comedy</option><option>Sci-Fi / Epic</option></select><select className="select-input" value={language} onChange={(event) => setLanguage(event.target.value)}><option value="all">All languages</option><option>Hindi</option><option>Telugu</option></select><select className="select-input" value={sort} onChange={(event) => setSort(event.target.value as "rating" | "release")}><option value="rating">Top rated</option><option value="release">Release date</option></select><SlidersHorizontal size={16} color="#77838f" /></div>
    {isLoading ? <div className="loading">Finding the right film…</div> : movies.length ? <div className="movie-grid">{movies.map((movie) => <MovieCard key={movie.id} movie={movie} />)}</div> : <div className="empty-state"><h3>No movies found</h3><p>Try a different title, genre, or language.</p><button className="secondary-button" onClick={() => { setSearch(""); setGenre("all"); setLanguage("all"); }}>Clear filters</button></div>}
  </div>;
}
