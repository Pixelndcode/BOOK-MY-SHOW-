import { ArrowLeft, Check, Circle, LockKeyhole, Ticket } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";

function SeatMapSkeleton() {
  return <div className="shell page seat-loading-page"><div className="loading-heading shimmer-block" /><div className="seat-layout skeleton-seat-layout"><div className="screen-bar shimmer-block" />{["A", "B", "C", "D"].map((row) => <div className="seat-row" key={row}><span className="row-label">{row}</span>{[1, 2, 3, 4, 5].map((seat) => <span className="seat skeleton-seat" key={seat} />)}</div>)}<div className="loading-label"><span className="loader-orbit small" /> Loading live seat availability…</div></div></div>;
}

export default function SeatBooking({ params }: { params: { id: string } }) {
  const showId = Number(params.id);
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const { data: show, isLoading } = trpc.shows.getById.useQuery({ id: showId });
  const [selectedSeats, setSelectedSeats] = useState<number[]>([]);
  const createBooking = trpc.bookings.create.useMutation({ onSuccess: (result) => navigate(`/payment/${result.id}`) });
  const rows = useMemo(() => show?.seats.reduce<Record<string, typeof show.seats>>((grouped, seat) => { (grouped[seat.rowLabel] ??= []).push(seat); return grouped; }, {}) ?? {}, [show]);
  if (isLoading) return <SeatMapSkeleton />;
  if (!show) return <div className="shell page"><div className="empty-state"><h2>Show not found</h2><Link href="/movies" className="primary-button">Back to movies</Link></div></div>;
  const total = selectedSeats.length * show.ticketPrice;
  const toggleSeat = (seatId: number) => setSelectedSeats((current) => current.includes(seatId) ? current.filter((id) => id !== seatId) : [...current, seatId]);
  const submit = () => { if (!isAuthenticated) { startLogin(); return; } if (!selectedSeats.length) return; createBooking.mutate({ showId, seatIds: selectedSeats }); };
  return <div className="shell page"><Link href={`/movie/${show.movieId}`} className="text-link" style={{ display: "inline-flex", alignItems: "center", gap: 7, marginBottom: 25 }}><ArrowLeft size={15} /> Back to showtimes</Link><div className="section-head"><div><div className="eyebrow">{show.theaterName} · {show.screenName}</div><h1 style={{ margin: "7px 0 4px", fontSize: 38 }}>Choose your seats</h1><p className="muted" style={{ margin: 0, fontSize: 13 }}>{show.movieTitle} · {show.showDate} · {show.showTime}</p></div><div className="detail-tag"><Ticket size={13} /> ₹{show.ticketPrice} per seat</div></div><div className="seat-layout"><div className="screen-bar">SCREEN</div>{Object.entries(rows).map(([row, seatsInRow]) => <div className="seat-row" key={row}><span className="row-label">{row}</span>{seatsInRow.map((seat) => { const booked = show.bookedSeatIds.includes(seat.id); const selected = selectedSeats.includes(seat.id); return <button key={seat.id} disabled={booked || createBooking.isPending} className={booked ? "seat booked" : selected ? "seat selected" : "seat"} onClick={() => toggleSeat(seat.id)} aria-label={`${seat.seatNumber}${booked ? " booked" : selected ? " selected" : " available"}`}>{selected ? <Check size={14} style={{ verticalAlign: "-2px" }} /> : seat.seatNumber}</button>; })}</div>)}<div className="seat-legend"><span><i className="legend-dot" /> Available</span><span><i className="legend-dot selected" /> Selected</span><span><i className="legend-dot booked" /> Booked</span></div></div><div className="checkout-layout" style={{ maxWidth: 780, margin: "0 auto" }}><div className="booking-summary"><div className="summary-line"><span>Selected seats</span><strong>{selectedSeats.length ? selectedSeats.map((id) => show.seats.find((seat) => seat.id === id)?.seatNumber).join(", ") : "None yet"}</strong></div><div className="summary-line"><span>Ticket price</span><strong>₹{show.ticketPrice}</strong></div><div className="summary-line"><span>Number of seats</span><strong>{selectedSeats.length}</strong></div><div className="summary-line"><span>Total amount</span><strong>₹{total}</strong></div></div><div><button className="primary-button booking-submit" style={{ width: "100%", padding: 15 }} onClick={submit} disabled={!selectedSeats.length || createBooking.isPending}>{createBooking.isPending ? <><Circle className="spin" size={15} /> Securing your seats…</> : isAuthenticated ? "Continue to payment" : "Sign in to continue"}</button>{createBooking.isPending && <div className="loading-label"><span className="loader-orbit small" /> Checking availability and reserving</div>}{createBooking.error && <p className="error-text" style={{ marginTop: 10 }}><LockKeyhole size={13} style={{ verticalAlign: "-2px" }} /> {createBooking.error.message}</p>}<p className="muted" style={{ fontSize: 11, lineHeight: 1.5, marginTop: 10 }}>Seats are held securely while you complete the mock payment.</p></div></div></div>;
}
