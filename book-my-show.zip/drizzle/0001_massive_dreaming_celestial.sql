CREATE TABLE `bookingSeats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingId` int NOT NULL,
	`showId` int NOT NULL,
	`seatId` int NOT NULL,
	CONSTRAINT `bookingSeats_id` PRIMARY KEY(`id`),
	CONSTRAINT `booking_show_seat_unique` UNIQUE(`showId`,`seatId`)
);
--> statement-breakpoint
CREATE TABLE `bookings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`showId` int NOT NULL,
	`bookingId` varchar(32) NOT NULL,
	`bookingDate` timestamp NOT NULL DEFAULT (now()),
	`totalAmount` int NOT NULL,
	`status` enum('PENDING','CONFIRMED','CANCELLED','FAILED') NOT NULL DEFAULT 'PENDING',
	`paymentMethod` varchar(32),
	`paymentId` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bookings_id` PRIMARY KEY(`id`),
	CONSTRAINT `bookings_bookingId_unique` UNIQUE(`bookingId`)
);
--> statement-breakpoint
CREATE TABLE `movies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`poster` text NOT NULL,
	`description` text NOT NULL,
	`genre` varchar(128) NOT NULL,
	`language` varchar(64) NOT NULL,
	`duration` int NOT NULL,
	`rating` int NOT NULL DEFAULT 0,
	`releaseDate` varchar(32) NOT NULL,
	`trailerUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `movies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingId` int NOT NULL,
	`paymentId` varchar(64) NOT NULL,
	`method` varchar(32) NOT NULL,
	`amount` int NOT NULL,
	`status` enum('SUCCESS','FAILED') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `payments_id` PRIMARY KEY(`id`),
	CONSTRAINT `payments_paymentId_unique` UNIQUE(`paymentId`)
);
--> statement-breakpoint
CREATE TABLE `screens` (
	`id` int AUTO_INCREMENT NOT NULL,
	`theaterId` int NOT NULL,
	`name` varchar(128) NOT NULL,
	`totalSeats` int NOT NULL DEFAULT 0,
	CONSTRAINT `screens_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `seats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`screenId` int NOT NULL,
	`seatNumber` varchar(16) NOT NULL,
	`rowLabel` varchar(8) NOT NULL,
	`seatType` varchar(32) NOT NULL DEFAULT 'STANDARD',
	CONSTRAINT `seats_id` PRIMARY KEY(`id`),
	CONSTRAINT `seats_screen_number_unique` UNIQUE(`screenId`,`seatNumber`)
);
--> statement-breakpoint
CREATE TABLE `shows` (
	`id` int AUTO_INCREMENT NOT NULL,
	`movieId` int NOT NULL,
	`theaterId` int NOT NULL,
	`screenId` int NOT NULL,
	`showDate` varchar(32) NOT NULL,
	`showTime` varchar(16) NOT NULL,
	`ticketPrice` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `shows_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `theaters` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`city` varchar(128) NOT NULL,
	`address` text NOT NULL,
	CONSTRAINT `theaters_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `booking_seats_booking_idx` ON `bookingSeats` (`bookingId`);--> statement-breakpoint
CREATE INDEX `bookings_user_idx` ON `bookings` (`userId`);--> statement-breakpoint
CREATE INDEX `bookings_show_idx` ON `bookings` (`showId`);--> statement-breakpoint
CREATE INDEX `movies_title_idx` ON `movies` (`title`);--> statement-breakpoint
CREATE INDEX `movies_genre_idx` ON `movies` (`genre`);--> statement-breakpoint
CREATE INDEX `movies_language_idx` ON `movies` (`language`);--> statement-breakpoint
CREATE INDEX `screens_theater_idx` ON `screens` (`theaterId`);--> statement-breakpoint
CREATE INDEX `shows_movie_idx` ON `shows` (`movieId`);--> statement-breakpoint
CREATE INDEX `shows_date_idx` ON `shows` (`showDate`);