CREATE TABLE `reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`movieId` int NOT NULL,
	`userId` int NOT NULL,
	`rating` int NOT NULL,
	`comment` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reviews_id` PRIMARY KEY(`id`),
	CONSTRAINT `reviews_user_movie_unique` UNIQUE(`userId`,`movieId`)
);
--> statement-breakpoint
CREATE INDEX `reviews_movie_idx` ON `reviews` (`movieId`);