import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, index, uniqueIndex } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const movies = mysqlTable("movies", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  poster: text("poster").notNull(),
  description: text("description").notNull(),
  genre: varchar("genre", { length: 128 }).notNull(),
  language: varchar("language", { length: 64 }).notNull(),
  duration: int("duration").notNull(),
  rating: int("rating").notNull().default(0),
  releaseDate: varchar("releaseDate", { length: 32 }).notNull(),
  trailerUrl: text("trailerUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  titleIdx: index("movies_title_idx").on(table.title),
  genreIdx: index("movies_genre_idx").on(table.genre),
  languageIdx: index("movies_language_idx").on(table.language),
}));

export const theaters = mysqlTable("theaters", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  city: varchar("city", { length: 128 }).notNull(),
  address: text("address").notNull(),
});

export const screens = mysqlTable("screens", {
  id: int("id").autoincrement().primaryKey(),
  theaterId: int("theaterId").notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  totalSeats: int("totalSeats").notNull().default(0),
}, (table) => ({
  theaterIdx: index("screens_theater_idx").on(table.theaterId),
}));

export const seats = mysqlTable("seats", {
  id: int("id").autoincrement().primaryKey(),
  screenId: int("screenId").notNull(),
  seatNumber: varchar("seatNumber", { length: 16 }).notNull(),
  rowLabel: varchar("rowLabel", { length: 8 }).notNull(),
  seatType: varchar("seatType", { length: 32 }).notNull().default("STANDARD"),
}, (table) => ({
  seatUnique: uniqueIndex("seats_screen_number_unique").on(table.screenId, table.seatNumber),
}));

export const shows = mysqlTable("shows", {
  id: int("id").autoincrement().primaryKey(),
  movieId: int("movieId").notNull(),
  theaterId: int("theaterId").notNull(),
  screenId: int("screenId").notNull(),
  showDate: varchar("showDate", { length: 32 }).notNull(),
  showTime: varchar("showTime", { length: 16 }).notNull(),
  ticketPrice: int("ticketPrice").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  movieIdx: index("shows_movie_idx").on(table.movieId),
  dateIdx: index("shows_date_idx").on(table.showDate),
}));

export const bookings = mysqlTable("bookings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  showId: int("showId").notNull(),
  bookingId: varchar("bookingId", { length: 32 }).notNull().unique(),
  bookingDate: timestamp("bookingDate").defaultNow().notNull(),
  totalAmount: int("totalAmount").notNull(),
  status: mysqlEnum("status", ["PENDING", "CONFIRMED", "CANCELLED", "FAILED"]).default("PENDING").notNull(),
  paymentMethod: varchar("paymentMethod", { length: 32 }),
  paymentId: varchar("paymentId", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("bookings_user_idx").on(table.userId),
  showIdx: index("bookings_show_idx").on(table.showId),
}));

export const bookingSeats = mysqlTable("bookingSeats", {
  id: int("id").autoincrement().primaryKey(),
  bookingId: int("bookingId").notNull(),
  showId: int("showId").notNull(),
  seatId: int("seatId").notNull(),
}, (table) => ({
  showSeatUnique: uniqueIndex("booking_show_seat_unique").on(table.showId, table.seatId),
  bookingIdx: index("booking_seats_booking_idx").on(table.bookingId),
}));

export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  bookingId: int("bookingId").notNull(),
  paymentId: varchar("paymentId", { length: 64 }).notNull().unique(),
  method: varchar("method", { length: 32 }).notNull(),
  amount: int("amount").notNull(),
  status: mysqlEnum("status", ["SUCCESS", "FAILED"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  movieId: int("movieId").notNull(),
  userId: int("userId").notNull(),
  rating: int("rating").notNull(),
  comment: text("comment").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  movieIdx: index("reviews_movie_idx").on(table.movieId),
  userMovieUnique: uniqueIndex("reviews_user_movie_unique").on(table.userId, table.movieId),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Movie = typeof movies.$inferSelect;
export type Theater = typeof theaters.$inferSelect;
export type Show = typeof shows.$inferSelect;
export type Seat = typeof seats.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type Review = typeof reviews.$inferSelect;
