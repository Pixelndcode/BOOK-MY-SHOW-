import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { and, eq } from "drizzle-orm";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { bookingSeats, bookings, movies, screens, seats, shows, theaters } from "../../drizzle/schema";
import { getDb } from "../db";
import { renderTicketPdf } from "../ticketPdf";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  app.get("/api/tickets/:id.pdf", async (req, res) => {
    try {
      const context = await createContext({ req, res } as any);
      if (!context.user) {
        res.status(401).json({ message: "Sign in to download your ticket." });
        return;
      }
      const db = await getDb();
      if (!db) {
        res.status(503).json({ message: "Ticket service is unavailable." });
        return;
      }
      const bookingRows = await db.select({
        bookingId: bookings.bookingId,
        paymentId: bookings.paymentId,
        paymentMethod: bookings.paymentMethod,
        totalAmount: bookings.totalAmount,
        movieTitle: movies.title,
        theaterName: theaters.name,
        theaterAddress: theaters.address,
        screenName: screens.name,
        showDate: shows.showDate,
        showTime: shows.showTime,
        bookingNumericId: bookings.id,
      }).from(bookings)
        .innerJoin(shows, eq(bookings.showId, shows.id))
        .innerJoin(movies, eq(shows.movieId, movies.id))
        .innerJoin(theaters, eq(shows.theaterId, theaters.id))
        .innerJoin(screens, eq(shows.screenId, screens.id))
        .where(and(eq(bookings.id, Number(req.params.id)), eq(bookings.userId, context.user.id), eq(bookings.status, "CONFIRMED")))
        .limit(1);
      const booking = bookingRows[0];
      if (!booking) {
        res.status(404).json({ message: "Confirmed booking not found." });
        return;
      }
      const seatRows = await db.select({ seatNumber: seats.seatNumber }).from(bookingSeats)
        .innerJoin(seats, eq(bookingSeats.seatId, seats.id))
        .where(eq(bookingSeats.bookingId, booking.bookingNumericId));
      const pdf = await renderTicketPdf({ ...booking, seatNumbers: seatRows.map((seat) => seat.seatNumber) });
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${booking.bookingId}.pdf"`);
      res.setHeader("Content-Length", pdf.length);
      res.end(pdf);
    } catch (error) {
      console.error("[Tickets] PDF generation failed:", error);
      res.status(500).json({ message: "Could not generate the ticket PDF." });
    }
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
