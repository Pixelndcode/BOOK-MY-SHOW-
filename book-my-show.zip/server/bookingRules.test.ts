import { describe, expect, it } from "vitest";
import { buildBookingCode, calculateTotal } from "./bookingRules";
import { fallbackMovies } from "./db";

describe("booking rules", () => {
  it("calculates the total from ticket price and selected seats", () => {
    expect(calculateTotal(250, [1, 2, 3])).toBe(750);
    expect(calculateTotal(320, [4])).toBe(320);
  });

  it("formats a stable BOOK MY SHOW booking code", () => {
    expect(buildBookingCode(new Date("2026-09-08T00:00:00Z"), "abc1234")).toBe("BMS-2026-ABC1234");
  });
});

describe("seeded movie catalog", () => {
  it("includes the expanded sample titles with poster data", () => {
    expect(fallbackMovies).toHaveLength(15);
    expect(fallbackMovies.map((movie) => movie.title)).toEqual(expect.arrayContaining(["Jawan", "Pathaan", "3 Idiots", "Stree 2", "Kalki 2898 AD", "Animal", "RRR", "Dangal", "Queen", "Drishyam 2", "Sita Ramam", "Vikram", "Kantara", "Laapataa Ladies", "The GOAT"]));
    expect(fallbackMovies.every((movie) => movie.poster.startsWith("https://"))).toBe(true);
  });
});
