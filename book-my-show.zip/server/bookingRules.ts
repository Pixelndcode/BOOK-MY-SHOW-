export function calculateTotal(ticketPrice: number, seatIds: number[]) {
  return ticketPrice * seatIds.length;
}

export function buildBookingCode(date: Date, suffix: string) {
  return `BMS-${date.getFullYear()}-${suffix.toUpperCase()}`;
}
