import { and, count, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, Movie, bookingSeats, movies, screens, seats, shows, theaters, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
let seedPromise: Promise<void> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

const catalogMovies = [
  { title: "Jawan", poster: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=900&q=85", description: "A high-energy action thriller about a vigilante who takes on a corrupt system with a team of fearless women.", genre: "Action", language: "Hindi", duration: 169, rating: 8, releaseDate: "12 Sep 2026", trailerUrl: "https://www.youtube.com/watch?v=MWOlnZSnXJo" },
  { title: "Pathaan", poster: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=900&q=85", description: "An elite spy returns from exile to stop a mercenary from unleashing chaos across the globe.", genre: "Action / Thriller", language: "Hindi", duration: 146, rating: 7, releaseDate: "18 Sep 2026", trailerUrl: "https://www.youtube.com/watch?v=vqu4z34wENw" },
  { title: "3 Idiots", poster: "https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=900&q=85", description: "Three friends, one unforgettable campus journey, and a story about choosing curiosity over convention.", genre: "Comedy / Drama", language: "Hindi", duration: 171, rating: 9, releaseDate: "20 Sep 2026", trailerUrl: "https://www.youtube.com/watch?v=K0eDlFX9GMc" },
  { title: "Stree 2", poster: "https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&w=900&q=85", description: "The town of Chanderi faces a new supernatural threat, and the gang is back for another hilarious night.", genre: "Horror / Comedy", language: "Hindi", duration: 149, rating: 8, releaseDate: "27 Sep 2026", trailerUrl: "https://www.youtube.com/watch?v=K0eDlFX9GMc" },
  { title: "Kalki 2898 AD", poster: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=900&q=85", description: "In a distant future, a reluctant hero becomes the last hope for a world waiting for a new beginning.", genre: "Sci-Fi / Epic", language: "Telugu", duration: 181, rating: 8, releaseDate: "02 Oct 2026", trailerUrl: "https://www.youtube.com/watch?v=kQDd1AhGIHk" },
  { title: "Animal", poster: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=900&q=85", description: "A turbulent father-son bond pulls a brilliant heir into a world of loyalty, ambition, and revenge.", genre: "Crime / Drama", language: "Hindi", duration: 201, rating: 7, releaseDate: "09 Oct 2026", trailerUrl: "https://www.youtube.com/watch?v=DVg2EJvvlF8" },
  { title: "RRR", poster: "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=900&q=85", description: "Two legendary revolutionaries form an unexpected friendship and rise together against an empire.", genre: "Action / Epic", language: "Telugu", duration: 187, rating: 9, releaseDate: "16 Oct 2026", trailerUrl: "https://www.youtube.com/watch?v=NgBoMJy386M" },
  { title: "Dangal", poster: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=900&q=85", description: "A determined father trains his daughters to become champions and rewrite the rules of the arena.", genre: "Biography / Drama", language: "Hindi", duration: 161, rating: 9, releaseDate: "23 Oct 2026", trailerUrl: "https://www.youtube.com/watch?v=x_7YlGv9u1g" },
  { title: "Queen", poster: "https://images.unsplash.com/photo-1521337581100-8ca9a73a5f79?auto=format&fit=crop&w=900&q=85", description: "After a broken engagement, a shy young woman takes a solo honeymoon and finds her own voice.", genre: "Comedy / Drama", language: "Hindi", duration: 146, rating: 8, releaseDate: "30 Oct 2026", trailerUrl: "https://www.youtube.com/watch?v=KGC6vl3yqt0" },
  { title: "Drishyam 2", poster: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&w=900&q=85", description: "A family’s carefully protected secret faces a new investigation in this gripping mystery sequel.", genre: "Crime / Thriller", language: "Hindi", duration: 140, rating: 8, releaseDate: "06 Nov 2026", trailerUrl: "https://www.youtube.com/watch?v=2fP6xQ5E0YQ" },
  { title: "Sita Ramam", poster: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=900&q=85", description: "A mysterious letter unlocks a timeless love story stretching across borders and generations.", genre: "Romance / Drama", language: "Telugu", duration: 163, rating: 8, releaseDate: "13 Nov 2026", trailerUrl: "https://www.youtube.com/watch?v=Ljk6tGZ1l3A" },
  { title: "Vikram", poster: "https://images.unsplash.com/photo-1518621736915-f3b1c41bfd00?auto=format&fit=crop&w=900&q=85", description: "A covert team hunts a ruthless drug syndicate while an old legend returns from the shadows.", genre: "Action / Thriller", language: "Tamil", duration: 174, rating: 8, releaseDate: "20 Nov 2026", trailerUrl: "https://www.youtube.com/watch?v=OKBMCL-frPU" },
  { title: "Kantara", poster: "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=900&q=85", description: "A fierce village protector is caught between ancestral traditions, land, and a changing world.", genre: "Action / Folklore", language: "Kannada", duration: 148, rating: 8, releaseDate: "27 Nov 2026", trailerUrl: "https://www.youtube.com/watch?v=8mrVmf239GU" },
  { title: "Laapataa Ladies", poster: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=900&q=85", description: "Two brides go missing from a train, setting off a warm, witty journey of identity and friendship.", genre: "Comedy / Drama", language: "Hindi", duration: 124, rating: 8, releaseDate: "04 Dec 2026", trailerUrl: "https://www.youtube.com/watch?v=sK3R0rvnlPs" },
  { title: "The GOAT", poster: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=85", description: "A former field agent is pulled back into one final mission where his past meets his future.", genre: "Action / Spy", language: "Tamil", duration: 179, rating: 7, releaseDate: "11 Dec 2026", trailerUrl: "https://www.youtube.com/watch?v=8sQd2p9c9uU" },
];

export async function ensureSeeded() {
  if (seedPromise) return seedPromise;
  seedPromise = (async () => {
    const db = await getDb();
    if (!db) return;
    const existingMovieRows = await db.select({ id: movies.id, title: movies.title }).from(movies);
    const existingMovieTitles = new Set(existingMovieRows.map((movie) => movie.title));
    const missingMovies = catalogMovies.filter((movie) => !existingMovieTitles.has(movie.title));
    if (missingMovies.length) await db.insert(movies).values(missingMovies);

    const [{ value: theaterCount }] = await db.select({ value: count() }).from(theaters);
    if (Number(theaterCount) === 0) {
      await db.insert(theaters).values([
        { name: "PVR Cinemas", city: "Mumbai", address: "Phoenix Marketcity, Kurla West" },
        { name: "INOX Megaplex", city: "Bengaluru", address: "Mantri Square, Malleshwaram" },
        { name: "Cinepolis", city: "Pune", address: "Seasons Mall, Magarpatta" },
      ]);
    }

    const [{ value: screenCount }] = await db.select({ value: count() }).from(screens);
    if (Number(screenCount) === 0) {
      const theaterRows = await db.select().from(theaters);
      const screenValues = theaterRows.map((theater) => ({ theaterId: theater.id, name: "Screen 1", totalSeats: 20 }));
      await db.insert(screens).values(screenValues);
      const screenRows = await db.select().from(screens);
      const seatValues = screenRows.flatMap((screen) => ["A", "B", "C", "D"].flatMap((row) => [1, 2, 3, 4, 5].map((num) => ({ screenId: screen.id, seatNumber: `${row}${num}`, rowLabel: row, seatType: row === "A" ? "PREMIUM" : "STANDARD" }))));
      await db.insert(seats).values(seatValues);
    }

    const movieRows = await db.select().from(movies);
    const showMovieRows = await db.select({ movieId: shows.movieId }).from(shows);
    const moviesWithShows = new Set(showMovieRows.map((show) => show.movieId));
    const moviesMissingShows = movieRows.filter((movie) => !moviesWithShows.has(movie.id));
    if (moviesMissingShows.length) {
      const theaterRows = await db.select().from(theaters);
      const screenRows = await db.select().from(screens);
      const showValues = moviesMissingShows.flatMap((movie, index) => {
        const theater = theaterRows[index % theaterRows.length];
        const screen = screenRows.find((item) => item.theaterId === theater.id) ?? screenRows[0];
        return [
          { movieId: movie.id, theaterId: theater.id, screenId: screen.id, showDate: "10 Sep 2026", showTime: "06:30 PM", ticketPrice: 250 },
          { movieId: movie.id, theaterId: theater.id, screenId: screen.id, showDate: "11 Sep 2026", showTime: "09:45 PM", ticketPrice: 320 },
        ];
      });
      await db.insert(shows).values(showValues);
    }
  })().catch((error) => {
    seedPromise = null;
    console.warn("[Database] Seed skipped:", error);
  });
  return seedPromise;
}

export const fallbackMovies: Movie[] = catalogMovies.map((movie, id) => ({ ...movie, id: id + 1, createdAt: new Date() }));
