import { and, asc, count, desc, eq, inArray, like, or, sql } from "drizzle-orm";
import { nanoid } from "nanoid";
import { z } from "zod";
import { bookingSeats, bookings, movies, payments, reviews, screens, seats, shows, theaters, users } from "../drizzle/schema";
import { getDb, ensureSeeded, fallbackMovies } from "./db";
import { buildBookingCode, calculateTotal } from "./bookingRules";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";

const movieFilters = z.object({ search: z.string().optional(), genre: z.string().optional(), language: z.string().optional(), sort: z.enum(["rating", "release"]).optional(), limit: z.number().optional() }).optional();

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  movies: router({
    list: publicProcedure.input(movieFilters).query(async ({ input }) => {
      await ensureSeeded();
      const db = await getDb();
      if (!db) return fallbackMovies;
      const filters = input ?? {};
      const predicates = [];
      if (filters.search) predicates.push(or(like(movies.title, `%${filters.search}%`), like(movies.genre, `%${filters.search}%`), like(movies.language, `%${filters.search}%`)));
      if (filters.genre && filters.genre !== "all") predicates.push(eq(movies.genre, filters.genre));
      if (filters.language && filters.language !== "all") predicates.push(eq(movies.language, filters.language));
      const rows = await db.select().from(movies).where(predicates.length ? and(...predicates) : undefined).orderBy(filters.sort === "release" ? asc(movies.releaseDate) : desc(movies.rating));
      return filters.limit ? rows.slice(0, filters.limit) : rows;
    }),
    get: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      await ensureSeeded();
      const db = await getDb();
      if (!db) return fallbackMovies.find((movie) => movie.id === input.id) ?? null;
      const result = await db.select().from(movies).where(eq(movies.id, input.id)).limit(1);
      return result[0] ?? null;
    }),
  }),
  reviews: router({
    list: publicProcedure.input(z.object({ movieId: z.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { reviews: [], average: 0, count: 0 };
      const rows = await db.select({ id: reviews.id, rating: reviews.rating, comment: reviews.comment, createdAt: reviews.createdAt, userName: users.name }).from(reviews).innerJoin(users, eq(reviews.userId, users.id)).where(eq(reviews.movieId, input.movieId)).orderBy(desc(reviews.createdAt));
      const average = rows.length ? rows.reduce((total, review) => total + review.rating, 0) / rows.length : 0;
      return { reviews: rows, average: Number(average.toFixed(1)), count: rows.length };
    }),
    create: protectedProcedure.input(z.object({ movieId: z.number(), rating: z.number().int().min(1).max(5), comment: z.string().trim().min(3).max(500) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Review service is not available." });
      const movie = await db.select({ id: movies.id }).from(movies).where(eq(movies.id, input.movieId)).limit(1);
      if (!movie[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Movie not found." });
      const existing = await db.select({ id: reviews.id }).from(reviews).where(and(eq(reviews.movieId, input.movieId), eq(reviews.userId, ctx.user.id))).limit(1);
      if (existing[0]) throw new TRPCError({ code: "CONFLICT", message: "You have already reviewed this movie." });
      await db.insert(reviews).values({ movieId: input.movieId, userId: ctx.user.id, rating: input.rating, comment: input.comment });
      return { success: true } as const;
    }),
  }),
  shows: router({
    forMovie: publicProcedure.input(z.object({ movieId: z.number() })).query(async ({ input }) => {
      await ensureSeeded();
      const db = await getDb();
      if (!db) return [];
      return db.select({ id: shows.id, showDate: shows.showDate, showTime: shows.showTime, ticketPrice: shows.ticketPrice, theaterId: theaters.id, theaterName: theaters.name, theaterCity: theaters.city, theaterAddress: theaters.address, screenId: screens.id, screenName: screens.name }).from(shows).innerJoin(theaters, eq(shows.theaterId, theaters.id)).innerJoin(screens, eq(shows.screenId, screens.id)).where(eq(shows.movieId, input.movieId)).orderBy(asc(shows.showDate), asc(shows.showTime));
    }),
    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      await ensureSeeded();
      const db = await getDb();
      if (!db) return null;
      const showRows = await db.select({ id: shows.id, movieId: shows.movieId, showDate: shows.showDate, showTime: shows.showTime, ticketPrice: shows.ticketPrice, movieTitle: movies.title, moviePoster: movies.poster, theaterName: theaters.name, theaterCity: theaters.city, theaterAddress: theaters.address, screenId: screens.id, screenName: screens.name }).from(shows).innerJoin(movies, eq(shows.movieId, movies.id)).innerJoin(theaters, eq(shows.theaterId, theaters.id)).innerJoin(screens, eq(shows.screenId, screens.id)).where(eq(shows.id, input.id)).limit(1);
      if (!showRows[0]) return null;
      const seatRows = await db.select({ id: seats.id, seatNumber: seats.seatNumber, rowLabel: seats.rowLabel, seatType: seats.seatType }).from(seats).where(eq(seats.screenId, showRows[0].screenId)).orderBy(asc(seats.id));
      const bookedRows = await db.select({ seatId: bookingSeats.seatId }).from(bookingSeats).innerJoin(bookings, eq(bookingSeats.bookingId, bookings.id)).where(and(eq(bookingSeats.showId, input.id), or(eq(bookings.status, "PENDING"), eq(bookings.status, "CONFIRMED"))));
      return { ...showRows[0], seats: seatRows, bookedSeatIds: bookedRows.map((row) => row.seatId) };
    }),
  }),
  bookings: router({
    create: protectedProcedure.input(z.object({ showId: z.number(), seatIds: z.array(z.number()).min(1).max(8) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Booking database is not available." });
      const show = await db.select().from(shows).where(eq(shows.id, input.showId)).limit(1);
      if (!show[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Show not found." });
      const seatRows = await db.select().from(seats).where(inArray(seats.id, input.seatIds));
      if (seatRows.length !== input.seatIds.length) throw new TRPCError({ code: "BAD_REQUEST", message: "One or more seats are invalid." });
      const bookingCode = buildBookingCode(new Date(), nanoid(7));
      try {
        return await db.transaction(async (tx) => {
          const occupied = await tx.select({ seatId: bookingSeats.seatId }).from(bookingSeats).where(and(eq(bookingSeats.showId, input.showId), inArray(bookingSeats.seatId, input.seatIds)));
          if (occupied.length) throw new TRPCError({ code: "CONFLICT", message: "One or more selected seats were just booked. Please choose again." });
          const totalAmount = calculateTotal(show[0].ticketPrice, input.seatIds);
          await tx.insert(bookings).values({ userId: ctx.user.id, showId: input.showId, bookingId: bookingCode, totalAmount, status: "PENDING" });
          const created = await tx.select({ id: bookings.id }).from(bookings).where(eq(bookings.bookingId, bookingCode)).limit(1);
          if (!created[0]) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not create booking." });
          await tx.insert(bookingSeats).values(input.seatIds.map((seatId) => ({ bookingId: created[0].id, showId: input.showId, seatId })));
          return { id: created[0].id, bookingId: bookingCode, totalAmount };
        });
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({ code: "CONFLICT", message: "Those seats are no longer available." });
      }
    }),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;
      const rows = await db.select({ id: bookings.id, bookingId: bookings.bookingId, totalAmount: bookings.totalAmount, status: bookings.status, paymentMethod: bookings.paymentMethod, paymentId: bookings.paymentId, bookingDate: bookings.bookingDate, showDate: shows.showDate, showTime: shows.showTime, ticketPrice: shows.ticketPrice, movieTitle: movies.title, moviePoster: movies.poster, theaterName: theaters.name, theaterAddress: theaters.address, screenName: screens.name }).from(bookings).innerJoin(shows, eq(bookings.showId, shows.id)).innerJoin(movies, eq(shows.movieId, movies.id)).innerJoin(theaters, eq(shows.theaterId, theaters.id)).innerJoin(screens, eq(shows.screenId, screens.id)).where(and(eq(bookings.id, input.id), eq(bookings.userId, ctx.user.id))).limit(1);
      if (!rows[0]) return null;
      const seatRows = await db.select({ seatNumber: seats.seatNumber }).from(bookingSeats).innerJoin(seats, eq(bookingSeats.seatId, seats.id)).where(eq(bookingSeats.bookingId, input.id));
      return { ...rows[0], seatNumbers: seatRows.map((seat) => seat.seatNumber) };
    }),
    mine: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      const rows = await db.select({ id: bookings.id, bookingId: bookings.bookingId, totalAmount: bookings.totalAmount, status: bookings.status, paymentMethod: bookings.paymentMethod, bookingDate: bookings.bookingDate, showDate: shows.showDate, showTime: shows.showTime, movieTitle: movies.title, moviePoster: movies.poster, theaterName: theaters.name, screenName: screens.name }).from(bookings).innerJoin(shows, eq(bookings.showId, shows.id)).innerJoin(movies, eq(shows.movieId, movies.id)).innerJoin(theaters, eq(shows.theaterId, theaters.id)).innerJoin(screens, eq(shows.screenId, screens.id)).where(eq(bookings.userId, ctx.user.id)).orderBy(desc(bookings.createdAt));
      return Promise.all(rows.map(async (row) => {
        const seatRows = await db.select({ seatNumber: seats.seatNumber }).from(bookingSeats).innerJoin(seats, eq(bookingSeats.seatId, seats.id)).where(eq(bookingSeats.bookingId, row.id));
        return { ...row, seatNumbers: seatRows.map((seat) => seat.seatNumber) };
      }));
    }),
  }),
  payments: router({
    pay: protectedProcedure.input(z.object({ bookingId: z.number(), method: z.enum(["UPI", "CARD", "NET_BANKING"]) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Payment service is not available." });
      const bookingRows = await db.select().from(bookings).where(and(eq(bookings.id, input.bookingId), eq(bookings.userId, ctx.user.id))).limit(1);
      if (!bookingRows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Booking not found." });
      if (bookingRows[0].status !== "PENDING") throw new TRPCError({ code: "BAD_REQUEST", message: "This booking is no longer payable." });
      const paymentId = `PAY-${nanoid(10).toUpperCase()}`;
      await db.transaction(async (tx) => {
        await tx.insert(payments).values({ bookingId: input.bookingId, paymentId, method: input.method, amount: bookingRows[0].totalAmount, status: "SUCCESS" });
        await tx.update(bookings).set({ status: "CONFIRMED", paymentMethod: input.method, paymentId }).where(eq(bookings.id, input.bookingId));
      });
      return { success: true, paymentId };
    }),
  }),
  admin: router({
    stats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { users: 0, movies: 0, theaters: 0, bookings: 0, confirmed: 0, cancelled: 0, revenue: 0 };
      const [[userCount], [movieCount], [theaterCount], [bookingCount], [confirmedCount], [cancelledCount], [revenue]] = await Promise.all([
        db.select({ value: count() }).from(users), db.select({ value: count() }).from(movies), db.select({ value: count() }).from(theaters), db.select({ value: count() }).from(bookings), db.select({ value: count() }).from(bookings).where(eq(bookings.status, "CONFIRMED")), db.select({ value: count() }).from(bookings).where(eq(bookings.status, "CANCELLED")), db.select({ value: sql<number>`coalesce(sum(${bookings.totalAmount}), 0)` }).from(bookings).where(eq(bookings.status, "CONFIRMED")),
      ]);
      return { users: Number(userCount.value), movies: Number(movieCount.value), theaters: Number(theaterCount.value), bookings: Number(bookingCount.value), confirmed: Number(confirmedCount.value), cancelled: Number(cancelledCount.value), revenue: Number(revenue.value) };
    }),
  }),
});

export type AppRouter = typeof appRouter;
