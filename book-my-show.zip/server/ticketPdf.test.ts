import { describe, expect, it } from "vitest";
import { renderTicketPdf } from "./ticketPdf";

describe("ticket PDF", () => {
  it("renders a non-empty PDF for a confirmed booking", async () => {
    const pdf = await renderTicketPdf({
      bookingId: "BMS-2026-TEST123",
      movieTitle: "Jawan",
      theaterName: "PVR Cinemas",
      theaterAddress: "Phoenix Marketcity, Kurla West",
      screenName: "Screen 1",
      showDate: "10 Sep 2026",
      showTime: "06:30 PM",
      seatNumbers: ["A1", "A2"],
      paymentId: "PAY-TEST123",
      paymentMethod: "UPI",
      totalAmount: 500,
    });

    expect(Buffer.isBuffer(pdf)).toBe(true);
    expect(pdf.subarray(0, 5).toString()).toBe("%PDF-");
    expect(pdf.length).toBeGreaterThan(2000);
  });
});
