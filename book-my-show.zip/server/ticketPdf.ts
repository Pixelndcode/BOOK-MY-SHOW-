import PDFDocument from "pdfkit";
import QRCode from "qrcode";

export type TicketPdfData = {
  bookingId: string;
  movieTitle: string;
  theaterName: string;
  theaterAddress: string;
  screenName: string;
  showDate: string;
  showTime: string;
  seatNumbers: string[];
  paymentId: string | null;
  paymentMethod: string | null;
  totalAmount: number;
};

export async function renderTicketPdf(ticket: TicketPdfData): Promise<Buffer> {
  const qrDataUrl = await QRCode.toDataURL(ticket.bookingId, { width: 150, margin: 1, errorCorrectionLevel: "M" });
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: "A4", margin: 48 });
    const chunks: Buffer[] = [];
    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);

    doc.rect(0, 0, 595, 842).fill("#0b0e12");
    doc.roundedRect(42, 42, 511, 758, 18).fill("#151b22").stroke("#394550");
    doc.fillColor("#ff6844").font("Helvetica-Bold").fontSize(10).text("BOOK MY SHOW", 70, 76, { characterSpacing: 1.4 });
    doc.fillColor("#f5f7fa").fontSize(27).text("Your movie night is confirmed", 70, 102);
    doc.fillColor("#ff947a").font("Courier-Bold").fontSize(13).text(ticket.bookingId, 70, 147);
    doc.image(qrDataUrl, 410, 76, { width: 105, height: 105 });

    doc.moveTo(70, 210).lineTo(525, 210).dash(4, { space: 4 }).stroke("#56616b");
    doc.undash();
    const field = (label: string, value: string, x: number, y: number, width = 210) => {
      doc.fillColor("#7e8b96").font("Helvetica-Bold").fontSize(8).text(label.toUpperCase(), x, y, { characterSpacing: 0.9, width });
      doc.fillColor("#f0f3f6").font("Helvetica").fontSize(13).text(value, x, y + 14, { width });
    };
    field("Movie", ticket.movieTitle, 70, 240, 300);
    field("Theater", ticket.theaterName, 70, 295);
    field("Address", ticket.theaterAddress, 70, 350, 430);
    field("Screen", ticket.screenName, 70, 405);
    field("Date", ticket.showDate, 300, 405);
    field("Show time", ticket.showTime, 70, 460);
    field("Seats", ticket.seatNumbers.join(", "), 300, 460);

    doc.roundedRect(70, 525, 455, 78, 10).fill("#202a33");
    field("Payment status", `${ticket.paymentMethod ?? "Mock"} · CONFIRMED`, 88, 545, 250);
    field("Total amount", `₹${ticket.totalAmount}`, 370, 545, 130);
    field("Payment ID", ticket.paymentId ?? "MOCK-PAYMENT", 70, 642, 300);
    doc.fillColor("#93a0aa").font("Helvetica").fontSize(11).text("Show this QR code at the cinema entrance", 70, 710);
    doc.fillColor("#ff947a").font("Helvetica-Bold").fontSize(11).text("Thank you for booking with BOOK MY SHOW", 70, 752);
    doc.end();
  });
}
